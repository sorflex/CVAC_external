#ifndef _BOWCV_H__
#define _BOWCV_H__

#include <stdio.h>
#include <stdlib.h>
#include <fstream>

#include <opencv2/opencv.hpp>
// #include <opencv2/opencv.hpp>
// #include <opencv2/highgui/highgui.hpp>
// #include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/nonfree.hpp>	//this should be included for using SIFT or SURF
// #include <opencv2/ml/ml.hpp>

// #ifdef _DEBUG
// #pragma comment(lib,"opencv_core242d.lib")
// #pragma comment(lib,"opencv_highgui242d.lib")
// #pragma comment(lib,"opencv_ml242d.lib")
// #pragma comment(lib,"opencv_nonfree242d.lib")
// #pragma comment(lib,"opencv_features2d242d.lib")
// #else
// #pragma comment(lib,"opencv_core242.lib")
// #pragma comment(lib,"opencv_highgui242.lib")
// #pragma comment(lib,"opencv_ml242.lib")
// #pragma comment(lib,"opencv_nonfree242.lib")
// #pragma comment(lib,"opencv_features2d242.lib")
// #endif



using namespace cv;
using namespace std;

#ifdef DLL_EXPORT
#define BOWLIBRARY_DLL	__declspec(dllexport)
#else
#define BOWLIBRARY_DLL	__declspec(dllimport)
#endif

class BOWLIBRARY_DLL bowCV {
public:
	bowCV();
	~bowCV();	
	
	BOOL			train_initialize(string _detectorName,string _extractorName,string _matcherName,int _nCluster);
	BOOL			train_parseTrainList(string _filepathTrain,string _filenameTrainList);
	void			train_stackTrainImage(string _fullpath,string _classID);	
	BOOL			train_run(string _filepathForSavingResult,string _filenameForSavingResult);

	BOOL			detect_initialize(string _filepath,string _filename);	
	BOOL			detect_setParameter(string _detectorName,string _extractorName,string _matcherName);	
	BOOL			detect_readTrainResult(string _filepath,string _filename);
	BOOL			detect_run(string _fullfilename, float _thresholdScore, int& _bestClass, float& _bestScore);
	

private:
	BOOL			train_writeVocabulary(const string& _filename,const Mat& _vocabulary);
	BOOL			detect_readVocabulary( const string& _filename, Mat& _vocabulary );
	BOOL			runTrainFull(string _filepathTrain,string _filenameTrainList,string _filepathForSavingResult,string _filenameForSavingResult);	//This function is not good to the ICE project.
	//void			setSVMParams( CvSVMParams& svmParams, CvMat& class_wts_cv, const Mat& responses, bool balanceClasses );
	//void			setSVMTrainAutoParams( CvParamGrid& c_grid, CvParamGrid& gamma_grid,CvParamGrid& p_grid, CvParamGrid& nu_grid,CvParamGrid& coef_grid, CvParamGrid& degree_grid );	
	
protected:
	Mat					_img;
	Mat					_descriptors;
	vector<KeyPoint>	_keypoints;
	string				_tfileName;
	char				_buf[255];
	string				_fullFilePathImg;
	string				_fullFilePathList;
	Mat					mVocabulary;
	string				filenameTrainResult;
	string				filenameVocabulary;	
	

private:
	int								cntCluster;
	BOOL							flagName;	
	BOOL							flagTrain;
	Ptr<FeatureDetector>			fDetector;	
	Ptr<DescriptorExtractor>		dExtractor;
	Ptr<DescriptorMatcher>			dMatcher;
	string							nameDetector;
	string							nameExtractor;
	string							nameMatcher;
	Ptr<BOWImgDescriptorExtractor>	bowExtractor;
	map<string,CvSVM>				classifierSVM;
	std::vector<string>				vFilenameTrain;
	std::vector<string>				vClassIDTrain;
};
#endif	//_BOWCV_H__